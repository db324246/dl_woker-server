module.exports = {
  url: 'mongodb://175.27.137.41:27000',
  libraryName: 'dl_worker'
}